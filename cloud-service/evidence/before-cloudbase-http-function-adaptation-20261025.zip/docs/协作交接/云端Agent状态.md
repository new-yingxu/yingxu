# 云端与 Agent 状态

更新时间：2026-10-25

## 已实现

- 新增 `cloud-service/` FastAPI 初版、Python 依赖锁 `requirements.lock`、CloudBase 容器 Dockerfile 和无凭据部署上下文脚本。
- 新增 SQLAlchemy 设备、同步事件、Agent 提议、同步偏好数据模型；本地开发可用 SQLite，生产配置拒绝 SQLite。
- 服务复用 `contracts/` 的两个 v1 schema；同步以 owner+eventId 及 owner+deviceId+sequence 双重幂等，冲突拒绝覆盖。
- 账号 owner、deviceId、origin 来自验签 JWT claims；真实身份服务尚未绑定。开发 token 仅在显式 `APP_ENV=development`、`AUTH_MODE=dev` 配置下可用，默认关闭。
- 设备注册/列表/撤销；撤销设备后 REST 和 WebSocket 下一轮检查会拒绝访问。
- 任务摘要同步、owner 限定快照与游标、路径同步开关和关闭时既有路径字段剔除。
- Agent 查询只搜索已同步的任务摘要；写操作仅保存带过期时间的提议/本地回执，不执行桌面写操作。移动端只能调用只读工具。
- WebSocket 首帧验权、初始事件快照、owner 限定增量轮询和 afterCursor 重连已实现；生产 JWT 可在共享身份 claims 对接后启用。
- `GET /healthz`、`GET /readyz`；默认认证关闭时 readiness 显示未就绪。
- OpenAPI 快照：`docs/云端与Agent/openapi.json`；部署步骤与风险：`infra/cloud/README.md`。

## 本地验证

- Python 3.14 虚拟环境安装 `cloud-service/requirements.txt` 成功；完整依赖锁由 uv 按 Python 3.12 解析生成。
- 临时 SQLite/显式开发 token 烟测通过：健康与就绪、缺少认证失败、设备注册、v1 事件写入/重放/冲突、设备 ID 伪造拒绝、快照、按 owner 查询、Agent 提议及不可越过本地授权状态机；另验证开发态 WebSocket 初始快照与手机只读/禁止桌面写操作。
- `pip check` 通过；OpenAPI 含 11 个 REST 路由。
- 烟测使用隔离临时数据库与虚构任务摘要，没有连接外部账号、上传原片或调用模型。

## 当前阻塞与未完成

- 2026-10-25 用户已创建体验环境 `yingxu-dev`，环境设置截图显示 ID `yingxu-dev-d8gowpye17ee27a61`；地域上海与 PostgreSQL 仍需控制台/CLI 进一步读回。当前机器仍未安装 `tcb`/Docker、未完成云端登录；没有执行部署，尚无服务 URL/线上健康/数据读回证据。配置进度见 `docs/云端与Agent/环境配置进度.md`。
- CloudBase 官方文档支持 CloudRun 容器服务及 `tcb cloudrun deploy`，但账号套餐、地域、环境、网络、费用、数据库资源和回滚能力仍需控制台核对。
- 生产需要共享数据库。已给出含 schema_migrations v1 标记的 MySQL schema 草案，但需按实际 CloudBase MySQL 版本和连接方式审阅并验证；生产 `/readyz` 会检查该版本标记；不得直接用 SQLite 托管多实例。
- 真实 JWT issuer/audience/JWKS、`sub`/`device_id`/`origin` 签发规则未与 CloudBase 认证或手机端身份对接。短信、邮箱、微信登录/回调、刷新、注销与账号合并未实现。
- 云端数据库账号隔离依赖 JWT issuer 正确绑定设备身份；上线前需加入不同账号隔离、撤销、旧事件防复活、删除/导出和恢复验收。
- Agent 现在是有限只读任务查询和提议记录，不是已接入大模型的完整 Agent；没有媒体目录索引或任意工具执行。模型供应商/BYOK 和用量尚未配置。
- Agent session 持久化、缩略图、完整删除标记/防复活、错误码覆盖、设备重新绑定审批仍未实现。
- 百度/夸克官方个人授权及上传能力尚未核实，未实现。

## 部署准备

- `python3 infra/cloud/prepare_context.py` 会生成干净的 `infra/cloud/build/`，只打包云服务代码、锁文件和共享 schema；脚本遇到已有目录会停止，不覆盖。
- 环境确认后，在生成目录运行 `tcb cloudrun deploy --port 8080`，选择已存在且获用户确认的环境/服务，不用 `--force` 创建或覆盖资源。
- 不把 `.env`、数据库连接串、JWT 配置材料或腾讯云令牌放进 Git、容器镜像或聊天。

## 桌面端联调提示

- REST 路由以 `docs/云端与Agent/openapi.json` 为准；已有 v1 schema 未修改。
- 仍需双方确认鉴权 claims、快照/删除游标、Agent action 状态及 WebSocket 消息格式后再由桌面端接入。
- 云端服务没有桌面路径、磁盘权限或源素材；云端提议不得替代本地预检/用户确认。
