# CloudBase 部署准备

此目录保存云端部署说明和模板，不包含账号凭据、环境 ID 或生产环境变量。

## 当前状态

- 容器应用源码：`../../cloud-service/`
- 目标：CloudBase 云托管容器服务；官方文档支持自定义容器/任意框架，CLI 部署命令为 `tcb cloudrun deploy`。
- 本仓库没有已确认的 CloudBase 环境、服务名、身份供应商、数据库连接、域名、预算或部署凭据，因此尚未执行云端创建/部署。
- 生产启动必须配置共享数据库、JWT issuer/audience/JWKS 与精确 HTTPS CORS 来源；禁止开发 token 和 SQLite。
- CloudBase Run 可按需缩容，资源按实际实例时长计量；配置最小实例数、数据库类型或专属资源前先核对账号套餐和费用。

## 本地启动

从 `cloud-service/` 目录创建虚拟环境、安装锁定的 `requirements.lock`，然后设置 `.env.example` 中的开发配置并运行：

```sh
uvicorn app.main:app --host 127.0.0.1 --port 8080
```

认证默认关闭，`/readyz` 会报告未就绪，所有业务 API 都拒绝匿名调用。只有显式设置 `APP_ENV=development`、`AUTH_MODE=dev` 和本地临时 `DEV_AUTH_TOKEN` 后，才可使用隔离开发身份；该模式不能部署到生产。

## 部署步骤（待环境确认）

1. 在 CloudBase 控制台确认环境 ID/地域、套餐与当前余量、云托管可用性、VPC/网络、公开访问策略、日志保留和回滚能力。
2. 选择并创建共享数据库。首选 CloudBase 环境实际支持且用户已开通的 MySQL；确认连接方式、TLS、最小权限用户、备份与恢复，再配置 `DATABASE_URL`。`schema.mysql.sql` 是版本 1 初始迁移草案，需按最终 CloudBase 数据库版本审阅/执行；生产 `/readyz` 检查 `schema_migrations` 的版本 1 标记。
3. 确认账号身份服务如何签发包含可信 `sub`、`device_id`、`origin` 的 JWT 及 JWKS 地址。配置 `AUTH_MODE=jwt`、issuer、audience、JWKS URL；未有此契约前保持认证关闭。
4. 在部署环境的 Secrets/环境变量界面填写配置，不提交 `.env`，不经聊天传递密钥。
5. 在仓库根目录运行 `python3 infra/cloud/prepare_context.py`，检查生成的 `infra/cloud/build/` 只含服务源码、锁文件和共享 schema；进入该目录运行 CloudBase CLI `tcb cloudrun deploy --port 8080`，按官方 CLI 交互选择既有环境及既有服务。首轮不使用 `--force`，不自动新建收费资源。
6. 部署后记录服务版本/commit、域名与访问策略；验证 `/healthz`、`/readyz`、TLS、实际鉴权、账号隔离、数据库读写、WebSocket 增量和回滚。

当前容器配置只代表准备就绪的应用源码，不代表 CloudBase 登录、数据持久化、Agent 模型或生产部署已经完成。

## 官方文档

- [CloudBase Run 容器部署](https://docs.cloudbase.net/cli-v1/cloudrun/deploy)
- [CloudBase Run WebSocket](https://docs.cloudbase.net/run/develop/access/websocket)
- [CloudBase 计算资源计量](https://cloud.tencent.com/document/product/876/120342)

